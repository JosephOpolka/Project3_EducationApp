package com.example.education_app

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.TextView
import com.example.languageapp.TopicSelect

class QuizTemplate : AppCompatActivity() {

private lateinit var returnButton: Button
private lateinit var titleLanguage: TextView
private lateinit var q1: RadioButton
private lateinit var q2: RadioButton
private lateinit var q3: RadioButton
private lateinit var q4: RadioButton
private var randomizedProblem: String? = null

        override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.quiz)

        titleLanguage = findViewById(R.id.quiz_title)
        q1 = findViewById(R.id.q1)
        q2 = findViewById(R.id.q2)
        q3 = findViewById(R.id.q3)
        q4 = findViewById(R.id.q4)

        returnButton = findViewById<Button>(R.id.quiz_button_return)
        returnButton.setOnClickListener {
        val intent = Intent(this, TopicSelect::class.java)
        startActivity(intent)
        }

        setQuizTitle()
        setQuizQuestions()

        val submitButton = findViewById<Button>(R.id.submit_button)
        submitButton.setOnClickListener {
        showCorrectAnswers()
        }
}

private fun setQuizTitle() {
        randomizedProblem = getRandomProblem()
        val problemText = when (randomizedProblem) {
        "addition" -> "What is the sum of 125 + 36?"
        "subtraction" -> "What is the result of 256 - 73?"
        "multiplication" -> "What is the product of 18 * 7?"
        "division" -> "What is the quotient of 2984 / 8?"
        else -> "What is a Math Problem?"
        }
        titleLanguage.text = problemText
        }

private fun getRandomProblem(): String {
        val problems = listOf("addition", "subtraction", "multiplication", "division")
        return problems.random()
        }

private fun setQuizQuestions() {
        val answers = getAnswers(randomizedProblem)

        q1.text = answers[0]
        q2.text = answers[1]
        q3.text = answers[2]
        q4.text = answers[3]
        }

private fun getAnswers(problem: String?): List<String> {
        return when (problem) {
        "addition" -> listOf("161", "163", "158", "170")
        "subtraction" -> listOf("179", "183", "173", "180")
        "multiplication" -> listOf("119", "133", "126", "140")
        "division" -> listOf("356", "378", "368", "373")
        else -> listOf("", "", "", "")
        }
}

private fun showCorrectAnswers() {
        val correctAnswers = getCorrectAnswers(randomizedProblem)

        // Disable all radio buttons
        q1.isEnabled = false
        q2.isEnabled = false
        q3.isEnabled = false
        q4.isEnabled = false

        when (correctAnswers.indexOf(true)) {
        0 -> q1.setTextColor(resources.getColor(R.color.white))
        1 -> q2.setTextColor(resources.getColor(R.color.white))
        2 -> q3.setTextColor(resources.getColor(R.color.white))
        3 -> q4.setTextColor(resources.getColor(R.color.white))
        }

        if (!correctAnswers[0]) q1.setTextColor(resources.getColor(R.color.wrong))
        if (!correctAnswers[1]) q2.setTextColor(resources.getColor(R.color.wrong))
        if (!correctAnswers[2]) q3.setTextColor(resources.getColor(R.color.wrong))
        if (!correctAnswers[3]) q4.setTextColor(resources.getColor(R.color.wrong))
        }

private fun getCorrectAnswers(problem: String?): List<Boolean> {
        return when (problem) {
        "addition" -> listOf(true, false, false, false)
        "subtraction" -> listOf(false, true, false, false)
        "multiplication" -> listOf(false, false, true, false)
        "division" -> listOf(false, false, false, true)
        else -> listOf(false, false, false, false)
        }
    }
}