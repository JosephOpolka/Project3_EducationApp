package com.example.languageapp

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.example.education_app.*

class TopicSelect : AppCompatActivity() {

    private lateinit var topicTitle: TextView
    private var selectedLanguage: String? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.topicselect)

        val backButton = findViewById<Button>(R.id.topicselect_button_back)
        backButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        val infoButton = findViewById<Button>(R.id.topic_button_info)
        infoButton.setOnClickListener {
            val intent = Intent(this, Information::class.java)
            startActivity(intent)
        }
        val flashButton = findViewById<Button>(R.id.topic_button_flash)
        flashButton.setOnClickListener {
            val intent = Intent(this, FlashCards::class.java)
            startActivity(intent)
        }
        val quizButton = findViewById<Button>(R.id.topic_button_quiz)
        quizButton.setOnClickListener {
            val intent = Intent(this, QuizTemplate::class.java)
            startActivity(intent)
        }
        val resourceButton = findViewById<Button>(R.id.topic_button_resource)
        resourceButton.setOnClickListener {
            val intent = Intent(this, Resources::class.java)
            startActivity(intent)
        }
    }
}