package com.example.education_app

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.languageapp.TopicSelect

class FlashCards : AppCompatActivity() {

    private lateinit var backButton: Button
    private lateinit var card1: Button
    private lateinit var card2: Button
    private lateinit var card3: Button
    private lateinit var card4: Button

    private var card1State = true
    private var card2State = true
    private var card3State = true
    private var card4State = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.flash)

        backButton = findViewById<Button>(R.id.back_cards)
        backButton.setOnClickListener {
            val intent = Intent(this, TopicSelect::class.java)
            startActivity(intent)
        }

        card1 = findViewById<Button>(R.id.card1)
        card1.setOnClickListener {
            card1State = !card1State // Toggles card text
            if (card1State) {
                card1.text = "125 + 36" // Question
            } else {
                card1.text = "125 + 36 ____ 161" // Answer
            }
        }
        card1.text = "125 + 36"

        card2 = findViewById<Button>(R.id.card2)
        card2.setOnClickListener {
            card2State = !card2State
            if (card2State) {
                card2.text = "256  - 73"
            } else {
                card2.text = "256  - 73 ____ 183"
            }
        }
        card2.text = "256  - 73"

        card3 = findViewById<Button>(R.id.card3)
        card3.setOnClickListener {
            card3State = !card3State
            if (card3State) {
                card3.text = "18    * 7"
            } else {
                card3.text = "18    * 7 ____ 126"
            }
        }
        card3.text = "18    * 7"

        card4 = findViewById<Button>(R.id.card4)
        card4.setOnClickListener {
            card4State = !card4State
            if (card4State) {
                card4.text = "2984  / 8"
            } else {
                card4.text = "2984  / 8 ____ 373"
            }
        }
        card4.text = "2984  / 8"
    }
}