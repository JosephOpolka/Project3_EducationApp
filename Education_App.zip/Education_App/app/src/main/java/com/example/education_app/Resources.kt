package com.example.education_app

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.languageapp.TopicSelect

class Resources : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.resources)

        val linkButton1 = findViewById<Button>(R.id.button_math)
        linkButton1.setOnClickListener {
            val url = "https://en.wikipedia.org/wiki/Mathematics"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        }
        val linkButton2 = findViewById<Button>(R.id.button_historyofmath)
        linkButton2.setOnClickListener {
            val url = "https://en.wikipedia.org/wiki/History_of_mathematics"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        }
        val backButton = findViewById<Button>(R.id.button_back)
        backButton.setOnClickListener {
            val intent = Intent(this, TopicSelect::class.java)
            startActivity(intent)
        }
    }
}