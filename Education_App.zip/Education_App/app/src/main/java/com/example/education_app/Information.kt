package com.example.education_app

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import com.example.languageapp.TopicSelect

class Information : AppCompatActivity() {

    private lateinit var backButton: Button
    private lateinit var overview: Button
    private lateinit var variants: Button
    private lateinit var bodyText: TextView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.info)

        backButton = findViewById<Button>(R.id.info_back)
        backButton.setOnClickListener {
            val intent = Intent(this, TopicSelect::class.java)
            startActivity(intent)
        }

        val textViewOverview = findViewById<TextView>(R.id.textViewOverview)
        val textViewVariants = findViewById<TextView>(R.id.textViewVariants)

        textViewOverview.visibility = View.VISIBLE
        textViewVariants.visibility = View.GONE

        overview = findViewById<Button>(R.id.button2)
        overview.setOnClickListener {
            textViewOverview.visibility = View.VISIBLE
            textViewVariants.visibility = View.GONE
        }

        variants = findViewById<Button>(R.id.button3)
        variants.setOnClickListener {
            textViewOverview.visibility = View.GONE
            textViewVariants.visibility = View.VISIBLE
        }
    }
}